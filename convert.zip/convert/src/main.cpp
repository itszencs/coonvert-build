#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QIcon>
#include <QQmlContext>
#include "license/LicenseManager.h"
#include "core/ConverterController.h"

int main(int argc, char *argv[]) {
    QGuiApplication app(argc, argv);
    app.setApplicationName("Coonvert");
    app.setOrganizationName("Coonvert");
    app.setWindowIcon(QIcon(":/icons/logo.png"));

    LicenseManager licenseManager;
    if (!licenseManager.isLicensed()) {
        qInfo() << "Modo Free activado";
    }

    ConverterController controller;

    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty("converter", &controller);
    engine.loadFromModule("Coonvert", "MainWindow");

    if (engine.rootObjects().isEmpty())
        return -1;

    return app.exec();
}
