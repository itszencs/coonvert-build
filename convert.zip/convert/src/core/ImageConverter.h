#pragma once
#include <QString>

class ImageConverter {
public:
    static bool convert(const QString& input, const QString& output,
                        const QString& format, int quality, int maxWidth);
};
