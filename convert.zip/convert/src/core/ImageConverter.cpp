#include "ImageConverter.h"
#include <glib-object.h>
#include <vips/vips.h>

bool ImageConverter::convert(const QString& input, const QString& output,
                              const QString& format, int quality, int maxWidth) {
    if (vips_init("coonvert") != 0) return false;

    VipsImage* in = vips_image_new_from_file(
        input.toUtf8().constData(), nullptr);
    if (!in) return false;

    VipsImage* processed = in;

    if (maxWidth > 0 && in->Xsize > maxWidth) {
        VipsImage* resized = nullptr;
        double scale = static_cast<double>(maxWidth) / in->Xsize;
        if (vips_resize(in, &resized, scale, nullptr) != 0) {
            g_object_unref(in);
            return false;
        }
        processed = resized;
    }

    if (format == "jpg" || format == "jpeg" || format == "webp") {
        vips_image_set_int(processed, "Q", quality);
    }

    int result = vips_image_write_to_file(
        processed, output.toUtf8().constData(), nullptr);

    if (processed != in) g_object_unref(processed);
    g_object_unref(in);
    return result == 0;
}
