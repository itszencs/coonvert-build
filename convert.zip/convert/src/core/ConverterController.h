#pragma once
#include <QObject>
#include <QStringList>
#include <QVariantList>

class ConverterController : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool running READ running NOTIFY runningChanged)
    Q_PROPERTY(int total READ total NOTIFY progressChanged)
    Q_PROPERTY(int done READ done NOTIFY progressChanged)
    Q_PROPERTY(QString currentFile READ currentFile NOTIFY progressChanged)

public:
    explicit ConverterController(QObject* parent = nullptr);

    bool running() const { return m_running; }
    int total() const { return m_total; }
    int done() const { return m_done; }
    QString currentFile() const { return m_currentFile; }

    Q_INVOKABLE void convertAll(const QStringList& files, const QString& format, int quality, int maxWidth = 0);
    Q_INVOKABLE bool resizeImageForEditor(const QString& inputPath, const QString& outputPath, int maxWidth, int maxHeight);
    Q_INVOKABLE bool composeFinalImage(const QString& basePath, const QString& editedPreviewPath, const QString& overlayJson, const QString& outputPath);

Q_SIGNALS:
    void runningChanged();
    void progressChanged();
    void fileDone(const QString& path, bool success, const QString& outputPath);
    void allDone(int okCount, int errorCount);

private:
    void processNext();
    bool isVideo(const QString& path) const;

    QStringList m_queue;
    QString m_format;
    int m_quality = 80;
    int m_maxWidth = 0;
    int m_total = 0;
    int m_done = 0;
    int m_ok = 0;
    int m_errors = 0;
    bool m_running = false;
    QString m_currentFile;
};
