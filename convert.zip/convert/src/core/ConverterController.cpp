#include "ConverterController.h"
#include "ImageConverter.h"
#include "VideoConverter.h"
#include <QFileInfo>
#include <QDir>
#include <QTimer>
#include <QImage>
#include <QPainter>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>

ConverterController::ConverterController(QObject* parent) : QObject(parent) {}

bool ConverterController::isVideo(const QString& path) const {
    QString ext = QFileInfo(path).suffix().toLower();
    return ext == "mp4" || ext == "mkv" || ext == "webm" || ext == "mov" || ext == "avi";
}

void ConverterController::convertAll(const QStringList& files, const QString& format, int quality, int maxWidth) {
    if (m_running) return;
    m_queue = files;
    m_format = format;
    m_quality = quality;
    m_maxWidth = maxWidth;
    m_total = files.size();
    m_done = 0;
    m_ok = 0;
    m_errors = 0;
    m_running = true;
    Q_EMIT runningChanged();
    Q_EMIT progressChanged();
    QTimer::singleShot(50, this, &ConverterController::processNext);
}

void ConverterController::processNext() {
    if (m_queue.isEmpty()) {
        m_running = false;
        m_currentFile.clear();
        Q_EMIT runningChanged();
        Q_EMIT progressChanged();
        Q_EMIT allDone(m_ok, m_errors);
        return;
    }
    QString path = m_queue.takeFirst();
    m_currentFile = QFileInfo(path).fileName();
    Q_EMIT progressChanged();

    QFileInfo fi(path);
    QString outExt = m_format;
    if (outExt == "jpeg") outExt = "jpg";
    QString outPath = fi.absolutePath() + "/" + fi.completeBaseName() + "_coonvert." + outExt;

    bool ok = false;
    if (isVideo(path)) {
        ok = VideoConverter::convert(path, outPath, m_format, m_quality);
    } else {
        ok = ImageConverter::convert(path, outPath, m_format, m_quality, m_maxWidth);
    }
    m_done++;
    if (ok) m_ok++; else m_errors++;
    Q_EMIT fileDone(path, ok, ok ? outPath : QString());
    Q_EMIT progressChanged();
    QTimer::singleShot(20, this, &ConverterController::processNext);
}

bool ConverterController::resizeImageForEditor(const QString& inputPath, const QString& outputPath, int maxWidth, int maxHeight) {
    QImage img(inputPath);
    if (img.isNull()) return false;
    QImage scaled = img.scaled(maxWidth, maxHeight, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    return scaled.save(outputPath, "PNG");
}

bool ConverterController::composeFinalImage(const QString& basePath, 
                                             const QString& editedPreviewPath,
                                             const QString& overlayJson, 
                                             const QString& outputPath) {
    QImage original(basePath);
    if (original.isNull()) return false;

    QImage preview(editedPreviewPath);

    QImage result = original.copy();
    QPainter painter(&result);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.setRenderHint(QPainter::SmoothPixmapTransform);

    // 1. Componer las anotaciones (preview escalado al tamaño original)
    if (!preview.isNull()) {
        QImage scaledPreview = preview.scaled(original.size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
        painter.drawImage(0, 0, scaledPreview);
    }

    // 2. Componer los overlays desde JSON
    QJsonDocument doc = QJsonDocument::fromJson(overlayJson.toUtf8());
    if (doc.isArray()) {
        QJsonArray arr = doc.array();

        double scaleX = 1.0;
        double scaleY = 1.0;
        if (!preview.isNull() && preview.width() > 0) {
            scaleX = static_cast<double>(original.width()) / preview.width();
            scaleY = static_cast<double>(original.height()) / preview.height();
        }

        for (const auto& item : arr) {
            QJsonObject obj = item.toObject();
            QString path = obj["path"].toString();
            double x = obj["x"].toDouble() * scaleX;
            double y = obj["y"].toDouble() * scaleY;
            double w = obj["width"].toDouble() * scaleX;
            double h = obj["height"].toDouble() * scaleY;
            double rot = obj["rotation"].toDouble();
            double op = obj["opacity"].toDouble();

            QImage overlay(path);
            if (overlay.isNull()) continue;

            QImage scaledOverlay = overlay.scaled(static_cast<int>(w), static_cast<int>(h),
                                                    Qt::KeepAspectRatio, Qt::SmoothTransformation);

            painter.save();
            painter.setOpacity(op);
            painter.translate(x + w / 2, y + h / 2);
            painter.rotate(rot);
            painter.translate(-scaledOverlay.width() / 2, -scaledOverlay.height() / 2);
            painter.drawImage(0, 0, scaledOverlay);
            painter.restore();
        }
    }

    painter.end();
    return result.save(outputPath, "PNG");
}
