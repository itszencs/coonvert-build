#include "FileQueue.h"

FileQueue::FileQueue(QObject* parent) : QObject(parent) {}

void FileQueue::addFiles(const QStringList& paths) {
    for (const auto& p : paths) {
        if (!m_files.contains(p)) m_files.append(p);
    }
    Q_EMIT filesChanged();
}

void FileQueue::clear() {
    m_files.clear();
    Q_EMIT filesChanged();
}
