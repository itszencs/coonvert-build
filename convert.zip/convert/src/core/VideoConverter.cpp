#include "VideoConverter.h"
#include <QProcess>

bool VideoConverter::convert(const QString& input, const QString& output,
                              const QString& format, int quality) {
    QProcess ffmpeg;
    QStringList args;
    args << "-i" << input << "-y";

    if (format == "webm") {
        args << "-c:v" << "libvpx-vp9"
             << "-crf" << QString::number(quality)
             << "-b:v" << "0"
             << "-c:a" << "libopus";
    } else {
        args << "-c:v" << "libx264"
             << "-preset" << "medium"
             << "-crf" << QString::number(quality)
             << "-c:a" << "aac"
             << "-b:a" << "128k";
    }
    args << output;

    ffmpeg.start("ffmpeg", args);
    ffmpeg.waitForFinished(-1);
    return ffmpeg.exitCode() == 0;
}
