#pragma once
#include <QObject>
#include <QStringList>

class FileQueue : public QObject {
    Q_OBJECT
public:
    explicit FileQueue(QObject* parent = nullptr);
    void addFiles(const QStringList& paths);
    void clear();
    int count() const { return m_files.size(); }
    QStringList files() const { return m_files; }

Q_SIGNALS:
    void filesChanged();

private:
    QStringList m_files;
};
