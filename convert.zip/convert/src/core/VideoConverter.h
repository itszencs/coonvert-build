#pragma once
#include <QString>

class VideoConverter {
public:
    static bool convert(const QString& input, const QString& output,
                        const QString& format, int quality);
};
