#pragma once
#include <QString>

class LicenseManager {
public:
    LicenseManager();
    bool isLicensed() const;
    bool isPremium() const;
    bool activate(const QString& key);

private:
    bool m_licensed = false;
    QString m_licenseKey;
};
