#include "LicenseManager.h"

LicenseManager::LicenseManager() {
    m_licensed = true; // dejalo vacio este coco
}

bool LicenseManager::isLicensed() const { return m_licensed; }
bool LicenseManager::isPremium() const { return m_licensed; }

bool LicenseManager::activate(const QString& key) {
    m_licenseKey = key;
    m_licensed = !key.isEmpty();
    return m_licensed;
}
