import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

ApplicationWindow {
    id: window
    visible: true
    width: 900
    height: 760
    minimumWidth: 700
    minimumHeight: 560
    title: "Coonvert"
    color: "#0a0a0f"

    property var files: []
    property var fileStatus: ({})
    property int okCount: 0
    property int errorCount: 0

    FileDialog {
        id: fileDialog
        title: "Elegí tus archivos"
        fileMode: FileDialog.OpenFiles
        nameFilters: [
            "Imágenes y video (*.jpg *.jpeg *.png *.webp *.avif *.mp4 *.mkv *.webm *.mov)",
            "Todos los archivos (*)"
        ]
        onAccepted: addFiles(selectedFiles)
    }

    function addFiles(paths) {
        for (var i = 0; i < paths.length; i++) {
            var p = paths[i].toString().replace("file://", "")
            if (files.indexOf(p) === -1) {
                files.push(p)
                fileStatus[p] = "pending"
            }
        }
        files = files.slice()
        fileStatus = Object.assign({}, fileStatus)
        toast.show(paths.length + " archivo" + (paths.length > 1 ? "s" : "") + " agregado" + (paths.length > 1 ? "s" : ""), "success")
    }

    function clearFiles() {
        files = []
        fileStatus = ({})
        okCount = 0
        errorCount = 0
    }

    function openEditor(path) {
        var comp = Qt.createComponent("EditorWindow.qml")
        if (comp.status === Component.Ready) {
            comp.createObject(window, { currentFile: path })
        } else {
            console.log("Error cargando editor:", comp.errorString())
            toast.show("No se pudo abrir el editor", "error")
        }
    }

    Toast {
        id: toast
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: 16
        z: 100
    }

    Connections {
        target: converter

        function onFileDone(path, success, outputPath) {
            fileStatus[path] = success ? "done" : "error"
            fileStatus = Object.assign({}, fileStatus)
        }

        function onAllDone(ok, errors) {
            okCount = ok
            errorCount = errors
            if (errors === 0) {
                toast.show("¡Listo! " + ok + " archivo" + (ok > 1 ? "s" : "") + " convertido" + (ok > 1 ? "s" : ""), "success")
            } else {
                toast.show(ok + " ok, " + errors + " con error", "error")
            }
        }

        function onProgressChanged() {
            progressBar.value = converter.total > 0 ? converter.done / converter.total : 0
        }
    }

    ColumnLayout {
        anchors.fill: parent
        anchors.margins: 32
        spacing: 20

        RowLayout {
            Layout.fillWidth: true
            spacing: 14

            Rectangle {
                width: 40
                height: 40
                radius: 10
                color: "transparent"
                clip: true

                Image {
                    anchors.fill: parent
                    source: "qrc:/icons/logo.png"
                    sourceSize: Qt.size(80, 80)
                    fillMode: Image.PreserveAspectCrop
                    smooth: true
                    mipmap: true
                }
            }

            ColumnLayout {
                spacing: 2

                Text {
                    text: "Coonvert"
                    font.family: "Inter, sans-serif"
                    font.pixelSize: 18
                    font.weight: Font.Bold
                    color: "#e8e8f0"
                }

                Text {
                    text: "Hecho por retardead."
                    font.family: "Inter, sans-serif"
                    font.pixelSize: 12
                    color: "#6b6b85"
                }
            }

            Item { Layout.fillWidth: true }

            Rectangle {
                visible: files.length > 0
                width: fileCountText.width + 24
                height: 28
                radius: 14
                color: "#181824"
                border.width: 1
                border.color: "#25253a"

                Text {
                    id: fileCountText
                    anchors.centerIn: parent
                    text: files.length + " archivos"
                    font.family: "Inter, sans-serif"
                    font.pixelSize: 12
                    font.weight: Font.Medium
                    color: "#a78bfa"
                }
            }
        }

        DropZone {
            id: dropZone
            Layout.fillWidth: true
            Layout.preferredHeight: files.length > 0 ? 140 : 260

            Behavior on Layout.preferredHeight {
                NumberAnimation { duration: 300; easing.type: Easing.OutCubic }
            }

            onFilesDropped: (paths) => addFiles(paths)
        }

        Rectangle {
            Layout.fillWidth: true
            Layout.fillHeight: true
            visible: files.length > 0
            color: "#0e0e15"
            radius: 14
            border.width: 1
            border.color: "#1e1e2c"

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 16
                spacing: 12

                RowLayout {
                    Layout.fillWidth: true

                    Text {
                        text: "Tus archivos"
                        font.family: "Inter, sans-serif"
                        font.pixelSize: 13
                        font.weight: Font.DemiBold
                        color: "#e8e8f0"
                    }

                    Item { Layout.fillWidth: true }

                    Text {
                        text: "Limpiar"
                        font.family: "Inter, sans-serif"
                        font.pixelSize: 12
                        color: clearHover.hovered ? "#e8e8f0" : "#6b6b85"
                        Behavior on color { ColorAnimation { duration: 150 } }

                        HoverHandler { id: clearHover; cursorShape: Qt.PointingHandCursor }
                        TapHandler { onTapped: clearFiles() }
                    }
                }

                ListView {
                    id: listView
                    Layout.fillWidth: true
                    Layout.fillHeight: true
                    clip: true
                    model: files
                    spacing: 6

                    delegate: FileItem {
                        width: listView.width
                        fileName: modelData.split("/").pop()
                        filePath: modelData
                        fileSize: ""
                        status: fileStatus[modelData] || "pending"
                        onEditRequested: window.openEditor(filePath)
                    }
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 14
            visible: files.length > 0

            RowLayout {
                Layout.fillWidth: true
                spacing: 20

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    Text {
                        text: "FORMATO"
                        font.family: "Inter, sans-serif"
                        font.pixelSize: 10
                        font.weight: Font.DemiBold
                        color: "#6b6b85"
                        font.letterSpacing: 0.5
                    }

                    ComboBox {
                        id: formatCombo
                        Layout.fillWidth: true
                        model: ["webp", "avif", "jpeg", "png", "mp4", "webm"]
                        font.family: "Inter, sans-serif"
                    }
                }

                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 6

                    RowLayout {
                        Layout.fillWidth: true

                        Text {
                            text: "CALIDAD"
                            font.family: "Inter, sans-serif"
                            font.pixelSize: 10
                            font.weight: Font.DemiBold
                            color: "#6b6b85"
                            font.letterSpacing: 0.5
                        }

                        Item { Layout.fillWidth: true }

                        Text {
                            text: Math.round(qualitySlider.value) + "%"
                            font.family: "Inter, sans-serif"
                            font.pixelSize: 12
                            font.weight: Font.DemiBold
                            color: "#a78bfa"
                        }
                    }

                    Slider {
                        id: qualitySlider
                        Layout.fillWidth: true
                        from: 1
                        to: 100
                        value: 80
                    }
                }
            }

            ProgressBar {
                id: progressBar
                Layout.fillWidth: true
                visible: converter.running || converter.done > 0
                value: 0

                background: Rectangle {
                    implicitHeight: 6
                    color: "#181824"
                    radius: 3
                }

                contentItem: Item {
                    Rectangle {
                        width: progressBar.visualPosition * parent.width
                        height: parent.height
                        radius: 3
                        color: "#7c5cfc"
                        Behavior on width { NumberAnimation { duration: 200 } }
                    }
                }
            }

            Text {
                Layout.fillWidth: true
                visible: converter.running
                text: converter.done + " / " + converter.total + " — " + converter.currentFile
                font.family: "Inter, sans-serif"
                font.pixelSize: 11
                color: "#6b6b85"
                elide: Text.ElideMiddle
            }

            AnimatedButton {
                Layout.fillWidth: true
                label: converter.running
                    ? "Procesando..."
                    : "Convertir " + files.length + " archivo" + (files.length > 1 ? "s" : "")
                primary: true
                enabled: !converter.running && files.length > 0

                onClicked: {
                    if (files.length === 0) return
                    okCount = 0
                    errorCount = 0
                    var s = ({})
                    for (var i = 0; i < files.length; i++) s[files[i]] = "pending"
                    fileStatus = s
                    converter.convertAll(files, formatCombo.currentText, qualitySlider.value)
                }
            }
        }

        Item { Layout.fillHeight: true }
    }
}
