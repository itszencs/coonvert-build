import QtQuick
import QtQuick.Controls

Button {
    id: root

    property string label: "Botón"
    property bool primary: true
    property color accentColor: "#7c5cfc"

    implicitHeight: 48
    implicitWidth: 200

    background: Rectangle {
        radius: 10
        color: root.primary
            ? (root.pressed ? "#6b4de6" : root.hovered ? "#8b6dff" : root.accentColor)
            : (root.hovered ? "#1e1e2c" : "#181824")
        border.width: root.primary ? 0 : 1
        border.color: "#25253a"

        Behavior on color { ColorAnimation { duration: 150 } }

        scale: root.pressed ? 0.98 : 1.0
        Behavior on scale { NumberAnimation { duration: 100 } }
    }

    contentItem: Text {
        text: root.label
        font.family: "Inter, sans-serif"
        font.pixelSize: 14
        font.weight: Font.DemiBold
        color: root.primary ? "white" : "#e8e8f0"
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
    }

    HoverHandler { cursorShape: Qt.PointingHandCursor }
}
