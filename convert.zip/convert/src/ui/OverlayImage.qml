import QtQuick
import QtQuick.Controls

Item {
    id: root
    property string imageSource: ""
    property real imageWidth: 200
    property real imageHeight: 200
    property real imageOpacity: 0.9
    property real imageRotation: 0
    property bool selected: false
    property string layerName: "Capa"

    signal removeRequested()
    signal selectedRequested()
    signal moved()

    width: imageWidth
    height: imageHeight
    rotation: imageRotation
    opacity: imageOpacity

    Image {
        id: img
        anchors.fill: parent
        source: root.imageSource
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
    }

    Rectangle {
        anchors.fill: parent
        anchors.margins: -2
        color: "transparent"
        border.width: root.selected ? 2 : 0
        border.color: "#7c5cfc"
        radius: 4
        visible: root.selected
    }

    Repeater {
        model: root.selected ? 4 : 0
        delegate: Rectangle {
            width: 12; height: 12; radius: 6
            color: "#7c5cfc"
            border.width: 2
            border.color: "white"
            x: (index % 2 === 0) ? -6 : parent.width - 6
            y: (index < 2) ? -6 : parent.height - 6

            MouseArea {
                anchors.fill: parent
                cursorShape: (index === 0 || index === 3) ? Qt.SizeFDiagCursor : Qt.SizeBDiagCursor
                property real sx: 0
                property real sy: 0
                property real sw: 0
                property real sh: 0

                onPressed: (mouse) => {
                    sx = mouse.x; sy = mouse.y
                    sw = root.imageWidth; sh = root.imageHeight
                }
                onPositionChanged: (mouse) => {
                    var dx = mouse.x - sx
                    var dy = mouse.y - sy
                    if (index === 0) { root.imageWidth = Math.max(40, sw - dx); root.imageHeight = Math.max(40, sh - dy) }
                    else if (index === 1) { root.imageWidth = Math.max(40, sw + dx); root.imageHeight = Math.max(40, sh - dy) }
                    else if (index === 2) { root.imageWidth = Math.max(40, sw - dx); root.imageHeight = Math.max(40, sh + dy) }
                    else if (index === 3) { root.imageWidth = Math.max(40, sw + dx); root.imageHeight = Math.max(40, sh + dy) }
                    root.moved()
                }
            }
        }
    }

    Rectangle {
        visible: root.selected
        width: 12; height: 12; radius: 6
        color: "#a78bfa"
        border.width: 2
        border.color: "white"
        x: parent.width / 2 - 6
        y: -20

        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.CrossCursor
            property real sa: 0
            onPressed: sa = root.imageRotation
            onPositionChanged: (mouse) => {
                var cx = root.width / 2
                var cy = root.height / 2
                var mx = mouse.x + parent.x
                var my = mouse.y + parent.y
                var angle = Math.atan2(my - cy, mx - cx) * 180 / Math.PI
                root.imageRotation = angle + 90
                root.moved()
            }
        }
    }

    Rectangle {
        visible: root.selected
        width: 22; height: 22; radius: 11
        color: "#f87171"
        border.width: 2
        border.color: "#0e0e15"
        x: parent.width - 10
        y: -10

        Text {
            anchors.centerIn: parent
            text: "x"
            color: "white"
            font.pixelSize: 11
            font.weight: Font.Bold
        }

        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.PointingHandCursor
            onClicked: root.removeRequested()
        }
    }

    MouseArea {
        anchors.fill: parent
        cursorShape: Qt.OpenHandCursor
        drag.target: root
        drag.axis: Drag.XAndYAxis
        propagateComposedEvents: false

        onPressed: root.selectedRequested()
        onPositionChanged: root.moved()
    }
}
