import QtQuick
import QtQuick.Dialogs

Rectangle {
    id: root
    signal filesDropped(var paths)

    property bool dragging: dropArea.containsDrag
    property bool hovered: mouseArea.containsMouse

    color: dragging ? "#1a1a2e" : hovered ? "#14141c" : "#111118"
    radius: 16
    border.width: 1
    border.color: dragging ? "#7c5cfc" : hovered ? "#2e2e42" : "#1e1e2c"

    Behavior on color { ColorAnimation { duration: 200 } }
    Behavior on border.color { ColorAnimation { duration: 200 } }

    function addPaths(paths) {
        if (paths && paths.length > 0) root.filesDropped(paths)
    }

    Column {
        anchors.centerIn: parent
        spacing: 16

        Rectangle {
            width: 56
            height: 56
            radius: 14
            anchors.horizontalCenter: parent.horizontalCenter
            color: root.dragging ? "#7c5cfc" : "#1a1a28"
            border.width: 1
            border.color: root.dragging ? "#7c5cfc" : "#2a2a3d"

            Behavior on color { ColorAnimation { duration: 200 } }

            Text {
                anchors.centerIn: parent
                text: "↑"
                font.pixelSize: 24
                font.weight: Font.Bold
                color: root.dragging ? "white" : "#8b8ba7"
            }
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.dragging ? "Soltá los archivos" : "Arrastrá tus archivos acá"
            font.family: "Inter, sans-serif"
            font.pixelSize: 16
            font.weight: Font.DemiBold
            color: "#e8e8f0"
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "o hacé clic para elegir"
            font.family: "Inter, sans-serif"
            font.pixelSize: 13
            color: "#6b6b85"
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: "JPG · PNG · WebP · AVIF · MP4 · MOV · MKV"
            font.family: "Inter, sans-serif"
            font.pixelSize: 11
            color: "#4a4a5e"
            topPadding: 8
        }
    }

    DropArea {
        id: dropArea
        anchors.fill: parent
        onDropped: (drop) => {
            var paths = []
            for (var i = 0; i < drop.urls.length; i++) {
                paths.push(drop.urls[i].toString().replace("file://", ""))
            }
            root.filesDropped(paths)
        }
    }

    MouseArea {
        id: mouseArea
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: fileDialog.open()
    }
}
