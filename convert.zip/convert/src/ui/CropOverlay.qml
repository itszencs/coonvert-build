import QtQuick
import QtQuick.Controls

Item {
    id: root
    property real cropX: 50
    property real cropY: 50
    property real cropW: 300
    property real cropH: 200
    property bool active: false

    signal cropConfirmed(real x, real y, real w, real h)
    signal cropCancelled()

    Rectangle {
        anchors.fill: parent
        color: "#00000099"
        visible: root.active

        MouseArea {
            anchors.fill: parent
            onClicked: root.cropCancelled()
        }
    }

    Rectangle {
        visible: root.active
        x: root.cropX
        y: root.cropY
        width: root.cropW
        height: root.cropH
        color: "transparent"
        border.width: 2
        border.color: "#7c5cfc"

        Rectangle { anchors.top: parent.top; width: parent.width; height: parent.height; color: "transparent" }

        Rectangle {
            x: -1; y: -30; width: 80; height: 24; radius: 4
            color: "#7c5cfc"
            Text {
                anchors.centerIn: parent
                text: Math.round(root.cropW) + " x " + Math.round(root.cropH)
                color: "white"
                font.pixelSize: 10
                font.weight: Font.DemiBold
            }
        }

        Repeater {
            model: 4
            delegate: Rectangle {
                width: 12; height: 12; radius: 6
                color: "#7c5cfc"
                border.width: 2
                border.color: "white"
                x: (index % 2 === 0) ? -6 : parent.width - 6
                y: (index < 2) ? -6 : parent.height - 6

                MouseArea {
                    anchors.fill: parent
                    cursorShape: (index === 0 || index === 3) ? Qt.SizeFDiagCursor : Qt.SizeBDiagCursor
                    property real sx: 0
                    property real sy: 0
                    property real sw: 0
                    property real sh: 0

                    onPressed: (mouse) => {
                        sx = mouse.x; sy = mouse.y
                        sw = root.cropW; sh = root.cropH
                    }
                    onPositionChanged: (mouse) => {
                        var dx = mouse.x - sx
                        var dy = mouse.y - sy
                        if (index === 0) { root.cropX += dx; root.cropY += dy; root.cropW = Math.max(40, sw - dx); root.cropH = Math.max(40, sh - dy) }
                        else if (index === 1) { root.cropY += dy; root.cropW = Math.max(40, sw + dx); root.cropH = Math.max(40, sh - dy) }
                        else if (index === 2) { root.cropX += dx; root.cropW = Math.max(40, sw - dx); root.cropH = Math.max(40, sh + dy) }
                        else if (index === 3) { root.cropW = Math.max(40, sw + dx); root.cropH = Math.max(40, sh + dy) }
                    }
                }
            }
        }

        MouseArea {
            anchors.fill: parent
            cursorShape: Qt.SizeAllCursor
            property real sx: 0
            property real sy: 0
            property real scx: 0
            property real scy: 0

            onPressed: (mouse) => {
                sx = mouse.x; sy = mouse.y
                scx = root.cropX; scy = root.cropY
            }
            onPositionChanged: (mouse) => {
                root.cropX = scx + (mouse.x - sx)
                root.cropY = scy + (mouse.y - sy)
            }
        }
    }

    Row {
        visible: root.active
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 20
        spacing: 12

        Rectangle {
            width: 100; height: 36; radius: 8
            color: "#7c5cfc"
            Text { anchors.centerIn: parent; text: "Aplicar"; color: "white"; font.pixelSize: 12; font.weight: Font.DemiBold }
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.cropConfirmed(root.cropX, root.cropY, root.cropW, root.cropH) }
        }
        Rectangle {
            width: 100; height: 36; radius: 8
            color: "#2a2a3a"
            Text { anchors.centerIn: parent; text: "Cancelar"; color: "#e8e8f0"; font.pixelSize: 12; font.weight: Font.DemiBold }
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.cropCancelled() }
        }
    }
}
