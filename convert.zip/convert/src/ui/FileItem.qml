import QtQuick
import QtQuick.Layouts

Rectangle {
    id: root
    property string fileName: ""
    property string fileSize: ""
    property string filePath: ""
    property string status: "pending"

    signal editRequested()

    height: 48
    radius: 10
    color: hoverArea.hovered ? "#181824" : "#13131c"
    border.width: 1
    border.color: "#1e1e2c"

    Behavior on color { ColorAnimation { duration: 150 } }

    opacity: 0
    Component.onCompleted: enterAnim.start()

    SequentialAnimation {
        id: enterAnim
        ParallelAnimation {
            NumberAnimation { target: root; property: "opacity"; to: 1; duration: 250; easing.type: Easing.OutCubic }
            NumberAnimation { target: root; property: "y"; from: 6; to: 0; duration: 250; easing.type: Easing.OutCubic }
        }
    }

    RowLayout {
        anchors.fill: parent
        anchors.leftMargin: 14
        anchors.rightMargin: 14
        spacing: 12

        Rectangle {
            width: 28
            height: 28
            radius: 8
            color: status === "done" ? "#0f2417"
                 : status === "error" ? "#2a1215"
                 : status === "processing" ? "#1a1535"
                 : "#1a1a28"
            border.width: 1
            border.color: status === "done" ? "#1e4a2d"
                 : status === "error" ? "#4a1e22"
                 : status === "processing" ? "#3d2d7a"
                 : "#25253a"

            Text {
                anchors.centerIn: parent
                text: status === "done" ? "✓"
                    : status === "error" ? "✕"
                    : status === "processing" ? "⟳"
                    : "◆"
                font.pixelSize: 13
                color: status === "done" ? "#4ade80"
                     : status === "error" ? "#f87171"
                     : status === "processing" ? "#a78bfa"
                     : "#5a5a72"

                RotationAnimation on rotation {
                    running: status === "processing"
                    from: 0; to: 360
                    duration: 1200
                    loops: Animation.Infinite
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 1

            Text {
                Layout.fillWidth: true
                text: root.fileName
                font.family: "Inter, sans-serif"
                font.pixelSize: 13
                font.weight: Font.Medium
                color: "#e8e8f0"
                elide: Text.ElideMiddle
            }

            Text {
                text: root.fileSize
                font.family: "Inter, sans-serif"
                font.pixelSize: 11
                color: "#5a5a72"
            }
        }

        Text {
            text: status === "done" ? "Listo"
                : status === "error" ? "Error"
                : status === "processing" ? "Procesando"
                : "En cola"
            font.family: "Inter, sans-serif"
            font.pixelSize: 11
            font.weight: Font.Medium
            color: status === "done" ? "#4ade80"
                 : status === "error" ? "#f87171"
                 : status === "processing" ? "#a78bfa"
                 : "#4a4a5e"
        }

        Rectangle {
            width: 28
            height: 28
            radius: 6
            color: editHover.hovered ? "#1e1e2c" : "transparent"
            visible: hoverArea.hovered && status !== "processing"

            Text {
                anchors.centerIn: parent
                text: "✎"
                color: "#8a8aa0"
                font.pixelSize: 14
            }

            HoverHandler { id: editHover; cursorShape: Qt.PointingHandCursor }
            TapHandler { onTapped: root.editRequested() }
        }
    }

    HoverHandler { id: hoverArea }
}
