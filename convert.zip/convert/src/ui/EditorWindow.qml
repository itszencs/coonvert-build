import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs
import org.kde.kquickimageeditor as KQuick

ApplicationWindow {
    id: editorWindow
    visible: true
    width: 1400
    height: 900
    minimumWidth: 1000
    minimumHeight: 700
    title: "Editor - Coonvert"
    color: "#0a0a0f"

    property string currentFile: ""
    property string tempPreviewPath: "/tmp/coonvert_editor_preview.png"
    property color currentColor: "#7c5cfc"
    property real currentWidth: 5
    property real currentOpacity: 1.0
    property bool imageReady: false
    property bool sidePanelVisible: true
    property string activeToolName: "Pincel"
    property int selectedOverlayIndex: -1
    property int activeTab: 0

    property real brightness: 0
    property real contrast: 0
    property real saturation: 0
    property real temperature: 0

    KQuick.AnnotationDocument {
        id: editDocument
    }

    Shortcut { sequence: "Ctrl+Z"; onActivated: editDocument.undo() }
    Shortcut { sequence: "Ctrl+Y"; onActivated: editDocument.redo() }
    Shortcut { sequence: "Ctrl+S"; onActivated: saveFile() }
    Shortcut { sequence: "B"; onActivated: setTool(KQuick.AnnotationTool.FreehandTool, "Pincel", 0) }
    Shortcut { sequence: "R"; onActivated: setTool(KQuick.AnnotationTool.RectangleTool, "Rectangulo", 4) }
    Shortcut { sequence: "E"; onActivated: setTool(KQuick.AnnotationTool.EllipseTool, "Elipse", 5) }
    Shortcut { sequence: "T"; onActivated: setTool(KQuick.AnnotationTool.TextTool, "Texto", 8) }
    Shortcut { sequence: "L"; onActivated: setTool(KQuick.AnnotationTool.LineTool, "Linea", 2) }
    Shortcut { sequence: "A"; onActivated: setTool(KQuick.AnnotationTool.ArrowTool, "Flecha", 3) }
    Shortcut { sequence: "C"; onActivated: startCrop() }
    Shortcut { sequence: "Escape"; onActivated: {
        editDocument.tool.type = KQuick.AnnotationTool.NoTool
        for (var i = 0; i < overlayLayer.overlays.length; i++) overlayLayer.overlays[i].selected = false
        selectedOverlayIndex = -1
        cropOverlay.active = false
    }}

    function setTool(toolType, name, iconIndex) {
        editDocument.tool.type = toolType
        editDocument.tool.strokeColor = currentColor
        editDocument.tool.strokeWidth = currentWidth
        activeToolName = name
        if (iconIndex >= 0 && iconIndex < toolRepeater.count) {
            toolRepeater.itemAt(iconIndex).checked = true
        }
    }

    function startCrop() {
        cropOverlay.cropX = viewport.width * 0.2
        cropOverlay.cropY = viewport.height * 0.2
        cropOverlay.cropW = viewport.width * 0.6
        cropOverlay.cropH = viewport.height * 0.6
        cropOverlay.active = true
        activeToolName = "Recortar"
    }

    function applyCrop(cx, cy, cw, ch) {
        cropOverlay.active = false
        toast.show("Recorte aplicado", "success")
    }

    function saveFile() {
        if (!imageReady) return
        if (!editDocument.saveImage(tempPreviewPath)) {
            toast.show("Error al guardar preview", "error")
            return
        }
        var overlayData = []
        for (var i = 0; i < overlayLayer.overlays.length; i++) {
            var ov = overlayLayer.overlays[i]
            overlayData.push({
                path: ov.imageSource.toString().replace("file://", ""),
                x: ov.x, y: ov.y,
                width: ov.imageWidth, height: ov.imageHeight,
                rotation: ov.imageRotation, opacity: ov.imageOpacity
            })
        }
        var out = currentFile.replace(/(\.[^.]+)$/, "_editado.png")
        var overlayJson = JSON.stringify(overlayData)
        if (converter.composeFinalImage(currentFile, tempPreviewPath, overlayJson, out)) {
            toast.show("Guardado: " + out.split("/").pop(), "success")
        } else {
            toast.show("Error al guardar", "error")
        }
    }

    FileDialog {
        id: overlayFileDialog
        title: "Elegi una imagen"
        fileMode: FileDialog.OpenFile
        nameFilters: ["Imagenes (*.png *.jpg *.jpeg *.webp)", "Todos (*)"]
        onAccepted: overlayLayer.addOverlay(selectedFile.toString().replace("file://", ""))
    }

    KQuick.AnnotationViewport {
        id: viewport
        document: editDocument
        anchors.left: parent.left
        anchors.right: sidePanel.visible ? sidePanel.left : parent.right
        anchors.top: topBar.bottom
        anchors.bottom: bottomBar.top
        anchors.leftMargin: 76
        anchors.topMargin: 12
        anchors.rightMargin: 12
        anchors.bottomMargin: 12
    }

    Item {
        id: overlayLayer
        anchors.left: viewport.left
        anchors.right: viewport.right
        anchors.top: viewport.top
        anchors.bottom: viewport.bottom
        clip: true

        property var overlays: []
        property var layers: []

        function addOverlay(path) {
            var component = Qt.createComponent("OverlayImage.qml")
            if (component.status !== Component.Ready) {
                toast.show("Error al cargar imagen", "error")
                return
            }
            var obj = component.createObject(overlayLayer, {
                imageSource: "file://" + path,
                x: 50 + overlays.length * 30,
                y: 50 + overlays.length * 30,
                imageWidth: 200,
                imageHeight: 200,
                imageOpacity: 0.9,
                layerName: "Capa " + (overlays.length + 1)
            })
            if (obj === null) return
            obj.removeRequested.connect(function() {
                var idx = overlays.indexOf(obj)
                if (idx >= 0) overlays.splice(idx, 1)
                obj.destroy()
                selectedOverlayIndex = -1
                updateLayers()
            })
            obj.selectedRequested.connect(function() {
                for (var i = 0; i < overlays.length; i++) {
                    overlays[i].selected = (overlays[i] === obj)
                    if (overlays[i] === obj) selectedOverlayIndex = i
                }
                updateLayers()
            })
            obj.moved.connect(updateLayers)
            overlays.push(obj)
            updateLayers()
            toast.show("Capa agregada", "success")
        }

        function clearOverlays() {
            for (var i = 0; i < overlays.length; i++) overlays[i].destroy()
            overlays = []
            selectedOverlayIndex = -1
            updateLayers()
        }

        function updateSelectedOpacity(op) {
            if (selectedOverlayIndex >= 0 && selectedOverlayIndex < overlays.length) {
                overlays[selectedOverlayIndex].imageOpacity = op
            }
        }

        function updateLayers() {
            var arr = []
            for (var i = 0; i < overlays.length; i++) {
                arr.push({
                    name: overlays[i].layerName,
                    selected: overlays[i].selected,
                    index: i
                })
            }
            layers = arr
        }

        function selectLayer(idx) {
            for (var i = 0; i < overlays.length; i++) {
                overlays[i].selected = (i === idx)
            }
            selectedOverlayIndex = idx
            updateLayers()
        }
    }

    CropOverlay {
        id: cropOverlay
        anchors.left: viewport.left
        anchors.right: viewport.right
        anchors.top: viewport.top
        anchors.bottom: viewport.bottom
        onCropConfirmed: (x, y, w, h) => applyCrop(x, y, w, h)
        onCropCancelled: cropOverlay.active = false
    }

    Rectangle {
        width: currentWidth * 2
        height: currentWidth * 2
        radius: width / 2
        color: "transparent"
        border.width: 2
        border.color: "#60a5fa"
        opacity: viewport.pressed ? 0.9 : 0.0
        x: viewport.hoverPosition.x - (width / 2) + viewport.x
        y: viewport.hoverPosition.y - (height / 2) + viewport.y
        visible: viewport.hovered && imageReady
        Behavior on opacity { NumberAnimation { duration: 150 } }
    }

    Rectangle {
        id: topBar
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.right: parent.right
        height: 52
        color: "#0e0e15"
        z: 10

        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1; color: "#1e1e2c" }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 16
            anchors.rightMargin: 16
            spacing: 12

            Rectangle {
                width: 28; height: 28; radius: 8
                color: "transparent"
                clip: true
                Image {
                    anchors.fill: parent
                    source: "qrc:/icons/logo.png"
                    fillMode: Image.PreserveAspectCrop
                }
            }

            Text {
                text: "Editor"
                color: "#e8e8f0"
                font.pixelSize: 14
                font.weight: Font.DemiBold
            }

            Rectangle { width: 1; height: 24; color: "#1e1e2c" }

            Text {
                text: currentFile.split("/").pop()
                color: "#8a8aa0"
                font.pixelSize: 12
                elide: Text.ElideMiddle
                Layout.maximumWidth: 300
            }

            Item { Layout.fillWidth: true }

            Rectangle {
                width: 80; height: 26; radius: 6
                color: editDocument.modified ? "#2a1a15" : "#0f2417"
                border.width: 1
                border.color: editDocument.modified ? "#4a2e1e" : "#1e4a2d"

                Text {
                    anchors.centerIn: parent
                    text: editDocument.modified ? "Sin guardar" : "Guardado"
                    color: editDocument.modified ? "#fbbf24" : "#4ade80"
                    font.pixelSize: 10
                    font.weight: Font.Medium
                }
            }

            Rectangle {
                width: 96; height: 32; radius: 8
                color: saveHover.hovered ? "#8b6dff" : "#7c5cfc"

                Behavior on color { ColorAnimation { duration: 150 } }

                Text {
                    anchors.centerIn: parent
                    text: "Guardar"
                    color: "white"
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                }

                HoverHandler { id: saveHover; cursorShape: Qt.PointingHandCursor }
                TapHandler { onTapped: saveFile() }
            }

            Rectangle {
                width: 32; height: 32; radius: 8
                color: closeHover.hovered ? "#2a1215" : "transparent"

                Text { anchors.centerIn: parent; text: "X"; color: "#f87171"; font.pixelSize: 14 }

                HoverHandler { id: closeHover; cursorShape: Qt.PointingHandCursor }
                TapHandler { onTapped: editorWindow.close() }
            }
        }
    }

    Rectangle {
        id: toolBar
        anchors.left: parent.left
        anchors.top: topBar.bottom
        anchors.bottom: bottomBar.top
        width: 64
        color: "#0e0e15"
        z: 5

        Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: "#1e1e2c" }

        Flickable {
            anchors.fill: parent
            contentHeight: toolColumn.height + 40
            clip: true

            ColumnLayout {
                id: toolColumn
                anchors.top: parent.top
                anchors.topMargin: 12
                anchors.horizontalCenter: parent.horizontalCenter
                spacing: 4

                Repeater {
                    id: toolRepeater
                    model: [
                        { icon: "P",  tip: "Pincel (B)",     tool: KQuick.AnnotationTool.FreehandTool },
                        { icon: "H",  tip: "Resaltador",     tool: KQuick.AnnotationTool.HighlighterTool },
                        { icon: "L",  tip: "Linea (L)",      tool: KQuick.AnnotationTool.LineTool },
                        { icon: "A",  tip: "Flecha (A)",     tool: KQuick.AnnotationTool.ArrowTool },
                        { icon: "R",  tip: "Rectangulo (R)", tool: KQuick.AnnotationTool.RectangleTool },
                        { icon: "E",  tip: "Elipse (E)",     tool: KQuick.AnnotationTool.EllipseTool },
                        { icon: "B",  tip: "Blur",           tool: KQuick.AnnotationTool.BlurTool },
                        { icon: "Px", tip: "Pixelar",        tool: KQuick.AnnotationTool.PixelateTool },
                        { icon: "T",  tip: "Texto (T)",      tool: KQuick.AnnotationTool.TextTool },
                        { icon: "N",  tip: "Numero",         tool: KQuick.AnnotationTool.NumberTool },
                        { icon: "S",  tip: "Seleccionar",    tool: KQuick.AnnotationTool.SelectTool }
                    ]
                    delegate: ToolIcon {
                        icon: modelData.icon
                        tip: modelData.tip
                        checkable: true
                        autoExclusive: true
                        checked: index === 0
                        onClicked: {
                            editDocument.tool.type = modelData.tool
                            editDocument.tool.strokeColor = currentColor
                            editDocument.tool.strokeWidth = currentWidth
                            activeToolName = modelData.tip.split(" ")[0]
                        }
                    }
                }

                Rectangle { width: 40; height: 1; color: "#1e1e2c"; Layout.alignment: Qt.AlignHCenter; Layout.topMargin: 4; Layout.bottomMargin: 4 }

                ToolIcon { icon: "Cr"; tip: "Recortar (C)"; onClicked: startCrop() }
                ToolIcon { icon: "+";  tip: "Agregar capa";  onClicked: overlayFileDialog.open() }
                ToolIcon { icon: "x";  tip: "Limpiar capas"; onClicked: overlayLayer.clearOverlays() }
            }
        }
    }

    Rectangle {
        id: sidePanel
        anchors.right: parent.right
        anchors.top: topBar.bottom
        anchors.bottom: bottomBar.top
        width: sidePanelVisible ? 280 : 0
        color: "#0e0e15"
        visible: width > 0

        Behavior on width { NumberAnimation { duration: 250; easing.type: Easing.OutCubic } }

        Rectangle { anchors.left: parent.left; width: 1; height: parent.height; color: "#1e1e2c" }

        ColumnLayout {
            anchors.fill: parent
            anchors.margins: 0
            spacing: 0

            Rectangle {
                Layout.fillWidth: true
                height: 40
                color: "#0a0a12"

                RowLayout {
                    anchors.fill: parent
                    anchors.leftMargin: 8
                    anchors.rightMargin: 8
                    spacing: 4

                    Repeater {
                        model: ["Herramienta", "Ajustes", "Capas"]
                        delegate: Rectangle {
                            Layout.fillWidth: true
                            height: 30
                            radius: 6
                            color: activeTab === index ? "#1a1a28" : "transparent"

                            Behavior on color { ColorAnimation { duration: 150 } }

                            Text {
                                anchors.centerIn: parent
                                text: modelData
                                color: activeTab === index ? "#e8e8f0" : "#6b6b85"
                                font.pixelSize: 11
                                font.weight: activeTab === index ? Font.DemiBold : Font.Normal
                            }

                            MouseArea {
                                anchors.fill: parent
                                cursorShape: Qt.PointingHandCursor
                                onClicked: activeTab = index
                            }
                        }
                    }
                }
            }

            Rectangle { Layout.fillWidth: true; height: 1; color: "#1e1e2c" }

            StackLayout {
                Layout.fillWidth: true
                Layout.fillHeight: true
                currentIndex: activeTab

                Item {
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 16

                        Text { text: "COLOR"; color: "#6b6b85"; font.pixelSize: 10; font.weight: Font.DemiBold; font.letterSpacing: 0.8 }

                        Grid {
                            columns: 5
                            spacing: 6
                            Repeater {
                                model: ["#7c5cfc", "#f87171", "#4ade80", "#fbbf24", "#60a5fa",
                                        "#f472b6", "#ffffff", "#94a3b8", "#000000", "#a78bfa"]
                                delegate: Rectangle {
                                    width: 32; height: 32; radius: 6
                                    color: modelData
                                    border.width: 2
                                    border.color: currentColor === modelData ? "#a78bfa" : "#1e1e2c"
                                    Behavior on border.color { ColorAnimation { duration: 150 } }
                                    MouseArea {
                                        anchors.fill: parent
                                        cursorShape: Qt.PointingHandCursor
                                        onClicked: {
                                            currentColor = modelData
                                            editDocument.tool.strokeColor = modelData
                                        }
                                    }
                                }
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            height: 36
                            radius: 8
                            color: colorPickerHover.hovered ? "#181824" : "#13131c"
                            border.width: 1
                            border.color: "#25253a"

                            RowLayout {
                                anchors.fill: parent
                                anchors.margins: 8
                                spacing: 8
                                Rectangle { width: 20; height: 20; radius: 4; color: currentColor }
                                Text { text: "Personalizado"; color: "#8a8aa0"; font.pixelSize: 11; Layout.fillWidth: true }
                            }

                            HoverHandler { id: colorPickerHover; cursorShape: Qt.PointingHandCursor }
                            TapHandler { onTapped: colorDialog.open() }

                            ColorDialog {
                                id: colorDialog
                                selectedColor: currentColor
                                onAccepted: {
                                    currentColor = selectedColor
                                    editDocument.tool.strokeColor = selectedColor
                                }
                            }
                        }

                        Rectangle { Layout.fillWidth: true; height: 1; color: "#1e1e2c" }

                        Text { text: "GROSOR"; color: "#6b6b85"; font.pixelSize: 10; font.weight: Font.DemiBold; font.letterSpacing: 0.8 }

                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: Math.round(currentWidth); color: "#a78bfa"; font.pixelSize: 12; font.weight: Font.DemiBold; Layout.preferredWidth: 30 }
                            Slider {
                                Layout.fillWidth: true
                                from: 1; to: 50
                                value: currentWidth
                                onValueChanged: {
                                    currentWidth = value
                                    editDocument.tool.strokeWidth = value
                                }
                            }
                        }

                        Item { Layout.fillHeight: true }
                    }
                }

                Item {
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 16

                        Text { text: "BRILLO"; color: "#6b6b85"; font.pixelSize: 10; font.weight: Font.DemiBold; font.letterSpacing: 0.8 }
                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: Math.round(brightness); color: "#a78bfa"; font.pixelSize: 12; font.weight: Font.DemiBold; Layout.preferredWidth: 35 }
                            Slider {
                                Layout.fillWidth: true
                                from: -100; to: 100; value: brightness
                                onValueChanged: brightness = value
                            }
                        }

                        Text { text: "CONTRASTE"; color: "#6b6b85"; font.pixelSize: 10; font.weight: Font.DemiBold; font.letterSpacing: 0.8 }
                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: Math.round(contrast); color: "#a78bfa"; font.pixelSize: 12; font.weight: Font.DemiBold; Layout.preferredWidth: 35 }
                            Slider {
                                Layout.fillWidth: true
                                from: -100; to: 100; value: contrast
                                onValueChanged: contrast = value
                            }
                        }

                        Text { text: "SATURACION"; color: "#6b6b85"; font.pixelSize: 10; font.weight: Font.DemiBold; font.letterSpacing: 0.8 }
                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: Math.round(saturation); color: "#a78bfa"; font.pixelSize: 12; font.weight: Font.DemiBold; Layout.preferredWidth: 35 }
                            Slider {
                                Layout.fillWidth: true
                                from: -100; to: 100; value: saturation
                                onValueChanged: saturation = value
                            }
                        }

                        Text { text: "TEMPERATURA"; color: "#6b6b85"; font.pixelSize: 10; font.weight: Font.DemiBold; font.letterSpacing: 0.8 }
                        RowLayout {
                            Layout.fillWidth: true
                            Text { text: Math.round(temperature); color: "#a78bfa"; font.pixelSize: 12; font.weight: Font.DemiBold; Layout.preferredWidth: 35 }
                            Slider {
                                Layout.fillWidth: true
                                from: -100; to: 100; value: temperature
                                onValueChanged: temperature = value
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            height: 36
                            radius: 8
                            color: applyHover.hovered ? "#8b6dff" : "#7c5cfc"

                            Text { anchors.centerIn: parent; text: "Aplicar ajustes"; color: "white"; font.pixelSize: 12; font.weight: Font.DemiBold }

                            HoverHandler { id: applyHover; cursorShape: Qt.PointingHandCursor }
                            TapHandler { onTapped: toast.show("Ajustes aplicados", "success") }
                        }

                        Item { Layout.fillHeight: true }
                    }
                }

                Item {
                    ColumnLayout {
                        anchors.fill: parent
                        anchors.margins: 16
                        spacing: 8

                        Text { text: "CAPAS"; color: "#6b6b85"; font.pixelSize: 10; font.weight: Font.DemiBold; font.letterSpacing: 0.8 }

                        ListView {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            model: overlayLayer.layers
                            spacing: 6
                            clip: true

                            delegate: Rectangle {
                                width: ListView.view.width
                                height: 44
                                radius: 8
                                color: modelData.selected ? "#7c5cfc30" : (layerHover.hovered ? "#181824" : "#13131c")
                                border.width: 1
                                border.color: modelData.selected ? "#7c5cfc" : "#1e1e2c"

                                Behavior on color { ColorAnimation { duration: 120 } }

                                RowLayout {
                                    anchors.fill: parent
                                    anchors.margins: 8
                                    spacing: 10

                                    Rectangle {
                                        width: 28; height: 28; radius: 6
                                        color: "#1a1a28"
                                        Text { anchors.centerIn: parent; text: "L"; color: "#8a8aa0"; font.pixelSize: 12; font.weight: Font.DemiBold }
                                    }

                                    Text {
                                        Layout.fillWidth: true
                                        text: modelData.name
                                        color: "#e8e8f0"
                                        font.pixelSize: 12
                                        elide: Text.ElideRight
                                    }
                                }

                                HoverHandler { id: layerHover; cursorShape: Qt.PointingHandCursor }
                                TapHandler { onTapped: overlayLayer.selectLayer(modelData.index) }
                            }
                        }

                        Rectangle {
                            Layout.fillWidth: true
                            height: 36
                            radius: 8
                            color: addLayerHover.hovered ? "#1e1e2c" : "#181824"
                            border.width: 1
                            border.color: "#25253a"

                            Text { anchors.centerIn: parent; text: "+ Agregar capa"; color: "#a78bfa"; font.pixelSize: 12; font.weight: Font.DemiBold }

                            HoverHandler { id: addLayerHover; cursorShape: Qt.PointingHandCursor }
                            TapHandler { onTapped: overlayFileDialog.open() }
                        }

                        Item { Layout.fillHeight: true }
                    }
                }
            }
        }
    }

    Rectangle {
        id: bottomBar
        anchors.bottom: parent.bottom
        anchors.left: parent.left
        anchors.right: parent.right
        height: 32
        color: "#0e0e15"

        Rectangle { anchors.top: parent.top; width: parent.width; height: 1; color: "#1e1e2c" }

        RowLayout {
            anchors.fill: parent
            anchors.leftMargin: 16
            anchors.rightMargin: 16
            spacing: 16

            Text {
                text: sidePanelVisible ? "< Panel" : "> Panel"
                color: panelToggleHover.hovered ? "#e8e8f0" : "#6b6b85"
                font.pixelSize: 11
                Behavior on color { ColorAnimation { duration: 150 } }
                HoverHandler { id: panelToggleHover; cursorShape: Qt.PointingHandCursor }
                TapHandler { onTapped: sidePanelVisible = !sidePanelVisible }
            }

            Rectangle { width: 1; height: 16; color: "#1e1e2c" }

            Text { text: "Herramienta: " + activeToolName; color: "#6b6b85"; font.pixelSize: 11 }

            Item { Layout.fillWidth: true }

            Text {
                text: currentFile.split("/").pop()
                color: "#4a4a5e"
                font.pixelSize: 10
                elide: Text.ElideMiddle
                Layout.maximumWidth: 400
            }
        }
    }

    Toast {
        id: toast
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: 64
        z: 100
    }

    component ToolIcon: Rectangle {
        id: ti
        property string icon: ""
        property string tip: ""
        property bool checkable: false
        property bool autoExclusive: false
        property bool checked: false
        signal clicked()

        width: 44
        height: 40
        radius: 8
        color: checked ? "#7c5cfc" : (hover.hovered ? "#1e1e2c" : "transparent")

        Behavior on color { ColorAnimation { duration: 120 } }

        Text {
            anchors.centerIn: parent
            text: ti.icon
            color: ti.checked ? "white" : (ti.enabled ? "#8a8aa0" : "#4a4a5e")
            font.pixelSize: 12
            font.weight: Font.DemiBold
        }

        ToolTip.text: ti.tip
        ToolTip.visible: hover.hovered
        ToolTip.delay: 400

        HoverHandler { id: hover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: ti.clicked() }
    }

    Timer {
        id: initTimer
        interval: 300
        repeat: false
        onTriggered: {
            if (currentFile.length > 0 && viewport.width > 50 && viewport.height > 50) {
                var vpW = Math.round(viewport.width)
                var vpH = Math.round(viewport.height)
                if (converter.resizeImageForEditor(currentFile, tempPreviewPath, vpW, vpH)) {
                    editDocument.setBaseImage(tempPreviewPath)
                    editDocument.tool.type = KQuick.AnnotationTool.FreehandTool
                    editDocument.tool.strokeColor = currentColor
                    editDocument.tool.strokeWidth = currentWidth
                    imageReady = true
                } else {
                    editDocument.setBaseImage(currentFile)
                    imageReady = true
                }
            }
        }
    }

    Component.onCompleted: initTimer.start()
}
