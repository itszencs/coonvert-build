import QtQuick

Rectangle {
    id: root

    property string message: ""
    property string kind: "info"

    width: contentRow.width + 28
    height: 40
    radius: 20

    color: "#181824"
    border.width: 1
    border.color: kind === "success" ? "#1e4a2d"
                : kind === "error" ? "#4a1e22"
                : "#25253a"

    opacity: 0

    Row {
        id: contentRow
        anchors.centerIn: parent
        spacing: 8

        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: kind === "success" ? "✓"
                : kind === "error" ? "✕"
                : "•"
            font.pixelSize: 14
            color: kind === "success" ? "#4ade80"
                 : kind === "error" ? "#f87171"
                 : "#a78bfa"
        }

        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: root.message
            font.family: "Inter, sans-serif"
            font.pixelSize: 13
            font.weight: Font.Medium
            color: "#e8e8f0"
        }
    }

    function show(msg, type) {
        root.message = msg
        root.kind = type || "info"
        showAnim.start()
        hideTimer.restart()
    }

    SequentialAnimation {
        id: showAnim
        ParallelAnimation {
            NumberAnimation { target: root; property: "opacity"; to: 1; duration: 250; easing.type: Easing.OutCubic }
            NumberAnimation { target: root; property: "y"; from: 0; to: 20; duration: 350; easing.type: Easing.OutBack }
        }
    }

    Timer {
        id: hideTimer
        interval: 2500
        onTriggered: hideAnim.start()
    }

    SequentialAnimation {
        id: hideAnim
        ParallelAnimation {
            NumberAnimation { target: root; property: "opacity"; to: 0; duration: 250 }
            NumberAnimation { target: root; property: "y"; to: 0; duration: 250 }
        }
    }
}
